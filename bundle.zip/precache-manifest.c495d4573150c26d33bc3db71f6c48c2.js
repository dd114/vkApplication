self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5bec42655cfe1818b13792628eeed6c8",
    "url": "/index.html"
  },
  {
    "revision": "6443b81b58fe6046ed5f",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "0a1c9b1caab17ae7c280",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "6443b81b58fe6046ed5f",
    "url": "/static/js/2.5cae9b50.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.5cae9b50.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0a1c9b1caab17ae7c280",
    "url": "/static/js/main.b1788804.chunk.js"
  },
  {
    "revision": "d43c770e24d0d0a2f611",
    "url": "/static/js/runtime-main.ebe38eeb.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);